'use client';

import { FormEvent, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Activity,
  BarChart3,
  CalendarDays,
  Check,
  ChevronRight,
  Clock,
  Copy,
  Heart,
  ImagePlus,
  Instagram,
  LayoutDashboard,
  ListChecks,
  Lock,
  MapPin,
  Menu,
  Phone,
  Plus,
  Scissors,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Star,
  Trash2,
  User,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBeautyData } from '@/lib/use-beauty-data';
import { Booking, BookingStatus, Service } from '@/lib/types';
import {
  formatDuration,
  formatMoney,
  getAvailableSlots,
  getDateString,
  getMaxBookingDate,
} from '@/lib/schedule';

const statusLabels: Record<BookingStatus, string> = {
  pending: 'Очікує',
  confirmed: 'Підтверджено',
  completed: 'Завершено',
  cancelled: 'Скасовано',
};

const statusClass: Record<BookingStatus, string> = {
  pending: 'bg-amber-100 text-amber-800',
  confirmed: 'bg-blue-100 text-blue-800',
  completed: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-rose-100 text-rose-800',
};

function publicUrl(slug: string) {
  if (typeof window === 'undefined') return `/master/${slug}`;
  return `${window.location.origin}/master/${slug}`;
}

function PageShell({ children }: { children: React.ReactNode }) {
  return <main className="min-h-screen bg-[#fff7fb] text-slate-950">{children}</main>;
}

function GradientPill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-pink-200 bg-white/70 px-3 py-1 text-sm text-pink-700 shadow-sm">
      {children}
    </span>
  );
}

function StatsCard({ title, value, description, icon: Icon }: { title: string; value: string; description: string; icon: any }) {
  return (
    <Card className="border-pink-100 bg-white/90 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
        <Icon className="h-5 w-5 text-pink-500" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="mt-1 text-xs text-slate-500">{description}</p>
      </CardContent>
    </Card>
  );
}

function AppTopbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-pink-100 bg-white/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-500 to-violet-500 text-white">
            <Sparkles className="h-5 w-5" />
          </span>
          BeautySlot
        </Link>
        <nav className="hidden items-center gap-2 md:flex">
          <Button asChild variant="ghost">
            <Link href="/master/angelina">Демо сторінка</Link>
          </Button>
          <Button asChild variant="ghost">
            <Link href="/login">Вхід</Link>
          </Button>
          <Button asChild className="bg-pink-600 hover:bg-pink-700">
            <Link href="/register">Створити профіль</Link>
          </Button>
        </nav>
        <Button asChild className="bg-pink-600 md:hidden">
          <Link href="/master/angelina">Демо</Link>
        </Button>
      </div>
    </header>
  );
}

export function LandingPage() {
  const steps = [
    ['1', 'Майстер створює сторінку', 'Додає опис, послуги, ціни, портфоліо та графік роботи.'],
    ['2', 'Клієнт відкриває посилання', 'Обирає послугу, дату, час і залишає контакти без реєстрації.'],
    ['3', 'Запис потрапляє в CRM', 'Майстер бачить бронювання, клієнта, суму та статус у кабінеті.'],
  ];

  return (
    <PageShell>
      <AppTopbar />
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-[1.1fr_0.9fr] md:py-20">
        <div className="flex flex-col justify-center">
          <GradientPill>
            <Sparkles className="mr-2 h-4 w-4" /> MVP для онлайн-запису майстрів
          </GradientPill>
          <h1 className="mt-6 max-w-3xl text-4xl font-black tracking-tight md:text-6xl">
            Онлайн-запис, послуги, графік і клієнти в одному сервісі
          </h1>
          <p className="mt-5 max-w-2xl text-lg text-slate-600">
            BeautySlot допомагає майстрам краси приймати записи через персональне посилання, а клієнтам — бронювати вільний час без зайвих повідомлень.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="bg-pink-600 hover:bg-pink-700">
              <Link href="/register">Створити сторінку запису</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-pink-200 bg-white">
              <Link href="/master/angelina">Переглянути демо</Link>
            </Button>
          </div>
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {['Публічна сторінка', 'CRM клієнтів', 'Розклад і слоти'].map((item) => (
              <div key={item} className="rounded-2xl border border-pink-100 bg-white/80 p-4 text-sm font-semibold shadow-sm">
                <Check className="mb-2 h-5 w-5 text-pink-500" /> {item}
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-[2rem] border border-pink-100 bg-white p-4 shadow-2xl shadow-pink-100">
          <div className="rounded-[1.5rem] bg-gradient-to-br from-pink-50 to-violet-50 p-4">
            <div className="flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80"
                alt="Master"
                className="h-20 w-20 rounded-3xl object-cover"
              />
              <div>
                <h3 className="text-2xl font-bold">Ангеліна</h3>
                <div className="mt-1 flex gap-1 text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="mt-1 text-sm text-slate-500">Майстер манікюру • Дніпро</p>
              </div>
            </div>
            <div className="mt-5 space-y-3">
              {[
                ['Манікюр з покриттям', '2 год', '600 ₴'],
                ['Педикюр з покриттям', '2 год', '650 ₴'],
                ['Нарощення нігтів', '2 год 30 хв', '750 ₴'],
              ].map(([name, time, price]) => (
                <div key={name} className="flex items-center justify-between rounded-2xl bg-white p-4 shadow-sm">
                  <div>
                    <p className="font-semibold">{name}</p>
                    <p className="text-sm text-slate-500">{time}</p>
                  </div>
                  <p className="font-bold text-pink-600">{price}</p>
                </div>
              ))}
            </div>
            <div className="mt-5 rounded-2xl bg-slate-950 p-4 text-white">
              <div className="flex items-center justify-between">
                <span>2 послуги • 4 год</span>
                <span className="font-bold">1250 ₴</span>
              </div>
              <Button className="mt-3 w-full bg-white text-slate-950 hover:bg-pink-50">Обрати час</Button>
            </div>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-4 pb-16">
        <div className="grid gap-4 md:grid-cols-3">
          {steps.map(([num, title, text]) => (
            <Card key={num} className="border-pink-100 bg-white/90">
              <CardHeader>
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-2xl bg-pink-100 font-bold text-pink-700">{num}</div>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{text}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>
    </PageShell>
  );
}

function ServiceSelector({ selected, onToggle, services }: { selected: string[]; onToggle: (id: string) => void; services: Service[] }) {
  const { data } = useBeautyData();
  const categories = data.categories.filter((cat) => services.some((srv) => srv.categoryId === cat.id));
  return (
    <div className="space-y-5">
      {categories.map((category) => {
        const categoryServices = services.filter((service) => service.categoryId === category.id);
        return (
          <section key={category.id}>
            <h3 className="mb-3 text-lg font-bold">{category.name}</h3>
            <div className="space-y-3">
              {categoryServices.map((service) => {
                const isSelected = selected.includes(service.id);
                return (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => onToggle(service.id)}
                    className={`w-full rounded-3xl border p-4 text-left transition ${
                      isSelected
                        ? 'border-pink-400 bg-pink-50 ring-2 ring-pink-100'
                        : 'border-pink-100 bg-white hover:border-pink-250'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-semibold">{service.name}</p>
                        <p className="mt-1 text-sm text-slate-500">{service.description}</p>
                        <p className="mt-2 text-sm text-slate-500">
                          <Clock className="mr-1 inline h-4 w-4" /> {formatDuration(service.durationMinutes)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-pink-600">{formatMoney(service.price)}</p>
                        <span className={`mt-2 inline-flex h-7 w-7 items-center justify-center rounded-full border ${isSelected ? 'border-pink-500 bg-pink-500 text-white' : 'border-slate-200 bg-white'}`}>
                          {isSelected && <Check className="h-4 w-4" />}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}

export function PublicMasterPage({ slug }: { slug: string }) {
  const { data, createBooking } = useBeautyData();
  const master = data.masters.find((item) => item.slug === slug) || data.masters[0];
  const services = data.services.filter((service) => service.masterId === master.id && service.isActive);
  const portfolio = data.portfolioImages.filter((img) => img.masterId === master.id).sort((a, b) => a.sortOrder - b.sortOrder);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [date, setDate] = useState(getDateString());
  const [time, setTime] = useState('');
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [lastBooking, setLastBooking] = useState<Booking | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', instagram: '', comment: '' });

  const selectedServices = services.filter((service) => selectedIds.includes(service.id));
  const totalPrice = selectedServices.reduce((sum, service) => sum + service.price, 0);
  const totalDuration = selectedServices.reduce((sum, service) => sum + service.durationMinutes, 0);
  const slots = getAvailableSlots({
    masterId: master.id,
    date,
    durationMinutes: totalDuration,
    workingHours: data.workingHours,
    breaks: data.breaks,
    exceptions: data.scheduleExceptions,
    bookings: data.bookings,
  });

  const toggle = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
    setTime('');
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!selectedIds.length || !date || !time || !form.name || !form.phone) return;
    const freshSlots = getAvailableSlots({
      masterId: master.id,
      date,
      durationMinutes: totalDuration,
      workingHours: data.workingHours,
      breaks: data.breaks,
      exceptions: data.scheduleExceptions,
      bookings: data.bookings,
    });
    if (!freshSlots.includes(time)) {
      alert('Цей слот вже недоступний. Оберіть інший час.');
      setTime('');
      return;
    }
    const booking = createBooking({
      masterId: master.id,
      serviceIds: selectedIds,
      date,
      startTime: time,
      clientName: form.name,
      clientPhone: form.phone,
      clientInstagram: form.instagram,
      comment: form.comment,
    });
    setLastBooking(booking);
    setIsConfirmed(true);
  };

  if (!master?.isPublic || !master?.isActive) {
    return (
      <PageShell>
        <div className="mx-auto flex min-h-screen max-w-xl flex-col items-center justify-center px-4 text-center">
          <Lock className="h-12 w-12 text-pink-500" />
          <h1 className="mt-4 text-3xl font-bold">Сторінка недоступна</h1>
          <p className="mt-2 text-slate-500">Майстер тимчасово приховав профіль або акаунт неактивний.</p>
        </div>
      </PageShell>
    );
  }

  if (isConfirmed && lastBooking) {
    return (
      <PageShell>
        <div className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-4 py-10">
          <Card className="border-pink-100 text-center shadow-xl shadow-pink-100">
            <CardHeader>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                <Check className="h-8 w-8" />
              </div>
              <CardTitle className="text-3xl">Ваш запис створено</CardTitle>
              <CardDescription>Майстер побачить заявку в кабінеті та зможе її підтвердити.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-left">
              <div className="rounded-2xl bg-pink-50 p-4">
                <p className="font-semibold">{master.name}</p>
                <p className="text-sm text-slate-500">{lastBooking.date} о {lastBooking.startTime}</p>
                <p className="mt-2 text-sm text-slate-600">{selectedServices.map((service) => service.name).join(', ')}</p>
                <p className="mt-2 font-bold text-pink-600">{formatMoney(lastBooking.totalPrice)} • {formatDuration(lastBooking.totalDurationMinutes)}</p>
              </div>
              <Button className="w-full bg-pink-600 hover:bg-pink-700" onClick={() => window.location.reload()}>
                Повернутися до профілю
              </Button>
            </CardContent>
          </Card>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="mx-auto max-w-3xl px-4 pb-28 pt-6">
        <Link href="/" className="mb-4 inline-flex items-center text-sm text-slate-500 hover:text-pink-600">
          BeautySlot <ChevronRight className="mx-1 h-4 w-4" /> Публічна сторінка
        </Link>
        <Card className="overflow-hidden border-pink-100 shadow-xl shadow-pink-100/70">
          <div className="h-28 bg-gradient-to-br from-pink-300 via-fuchsia-200 to-violet-300" />
          <CardContent className="-mt-12 pb-6">
            <div className="flex items-end gap-4">
              <img src={master.avatarUrl} alt={master.name} className="h-24 w-24 rounded-3xl border-4 border-white object-cover shadow-lg" />
              <div className="pb-2">
                <h1 className="text-3xl font-black">{master.name}</h1>
                <div className="mt-1 flex gap-1 text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
                  <span className="ml-2 text-sm text-slate-500">5.0</span>
                </div>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              {master.specialties.map((item) => <Badge key={item} className="bg-pink-100 text-pink-700 hover:bg-pink-100">{item}</Badge>)}
            </div>
            <p className="mt-4 text-slate-600">{master.description}</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-pink-50 p-4">
                <MapPin className="mb-2 h-5 w-5 text-pink-600" />
                <p className="font-semibold">{master.city}</p>
                <p className="text-sm text-slate-500">{master.address}</p>
              </div>
              <div className="rounded-2xl bg-violet-50 p-4">
                <Instagram className="mb-2 h-5 w-5 text-violet-600" />
                <p className="font-semibold">{master.instagram}</p>
                <p className="text-sm text-slate-500">Напишіть після запису, якщо треба уточнення.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <section className="mt-7">
          <h2 className="mb-3 text-2xl font-bold">Портфоліо</h2>
          <div className="grid grid-cols-3 gap-3">
            {portfolio.map((image) => (
              <div key={image.id} className="overflow-hidden rounded-3xl bg-white shadow-sm">
                <img src={image.imageUrl} alt={image.caption} className="h-32 w-full object-cover sm:h-44" />
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8">
          <h2 className="mb-4 text-2xl font-bold">Оберіть послуги</h2>
          <ServiceSelector selected={selectedIds} onToggle={toggle} services={services} />
        </section>

        <section className="mt-8 rounded-3xl border border-pink-100 bg-white p-5 shadow-sm">
          <h2 className="text-2xl font-bold">Онлайн-запис</h2>
          <p className="mt-1 text-sm text-slate-500">Спочатку оберіть послуги, потім дату і доступний час.</p>
          <form className="mt-5 space-y-5" onSubmit={submit}>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Дата</Label>
                <Input type="date" min={getDateString()} max={getMaxBookingDate(30)} value={date} onChange={(e) => { setDate(e.target.value); setTime(''); }} />
              </div>
              <div>
                <Label>Обраний час</Label>
                <Input value={time || 'Оберіть слот нижче'} readOnly />
              </div>
            </div>
            <div>
              <Label>Доступний час</Label>
              {!selectedIds.length ? (
                <p className="mt-2 rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">Оберіть хоча б одну послугу, щоб побачити доступні слоти.</p>
              ) : slots.length ? (
                <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-5">
                  {slots.map((slot) => (
                    <button
                      type="button"
                      key={slot}
                      onClick={() => setTime(slot)}
                      className={`rounded-2xl border px-3 py-2 text-sm font-semibold ${time === slot ? 'border-pink-500 bg-pink-500 text-white' : 'border-pink-100 bg-pink-50 text-pink-700'}`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              ) : (
                <p className="mt-2 rounded-2xl bg-rose-50 p-4 text-sm text-rose-700">Немає доступних слотів на цю дату для обраної тривалості.</p>
              )}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Імʼя *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ваше імʼя" />
              </div>
              <div>
                <Label>Телефон *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+380..." />
              </div>
              <div>
                <Label>Instagram</Label>
                <Input value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} placeholder="@username" />
              </div>
              <div>
                <Label>Коментар</Label>
                <Input value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} placeholder="Побажання до запису" />
              </div>
            </div>
            <Button disabled={!selectedIds.length || !time || !form.name || !form.phone} className="w-full bg-pink-600 hover:bg-pink-700" size="lg">
              Записатись
            </Button>
          </form>
        </section>
      </div>

      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-pink-100 bg-white/95 p-3 shadow-2xl backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-3">
          <div>
            <p className="text-sm font-semibold">{selectedIds.length} послуг • {formatDuration(totalDuration)}</p>
            <p className="font-bold text-pink-600">{formatMoney(totalPrice)}</p>
          </div>
          <Button className="bg-pink-600 hover:bg-pink-700" onClick={() => document.querySelector('form')?.scrollIntoView({ behavior: 'smooth' })}>
            Обрати час
          </Button>
        </div>
      </div>
    </PageShell>
  );
}

function DashboardShell({ children, title, description }: { children: React.ReactNode; title: string; description: string }) {
  const [open, setOpen] = useState(false);
  const nav: Array<[string, string, any]> = [
    ['Огляд', '/dashboard', LayoutDashboard],
    ['Профіль', '/dashboard/profile', User],
    ['Послуги', '/dashboard/services', Scissors],
    ['Графік', '/dashboard/schedule', CalendarDays],
    ['Записи', '/dashboard/bookings', ListChecks],
    ['Клієнти', '/dashboard/clients', Users],
    ['Портфоліо', '/dashboard/portfolio', ImagePlus],
    ['Аналітика', '/dashboard/analytics', BarChart3],
  ];
  return (
    <PageShell>
      <div className="flex min-h-screen">
        <aside className="hidden w-72 border-r border-pink-100 bg-white p-4 md:block">
          <Link href="/" className="mb-8 flex items-center gap-2 font-bold">
            <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-pink-600 text-white"><Sparkles className="h-5 w-5" /></span>
            BeautySlot
          </Link>
          <nav className="space-y-1">
            {nav.map(([label, href, Icon]) => (
              <Button key={href as string} asChild variant="ghost" className="w-full justify-start">
                <Link href={href as string}><Icon className="mr-2 h-4 w-4" /> {label as string}</Link>
              </Button>
            ))}
          </nav>
          <Button asChild className="mt-8 w-full bg-pink-600 hover:bg-pink-700">
            <Link href="/master/angelina">Відкрити публічну сторінку</Link>
          </Button>
        </aside>
        <div className="flex-1">
          <header className="sticky top-0 z-30 border-b border-pink-100 bg-white/90 backdrop-blur">
            <div className="flex items-center justify-between px-4 py-4 md:px-8">
              <div>
                <h1 className="text-2xl font-black">{title}</h1>
                <p className="text-sm text-slate-500">{description}</p>
              </div>
              <Button variant="outline" size="icon" className="md:hidden" onClick={() => setOpen(!open)}>
                {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
            {open && (
              <nav className="grid gap-1 border-t border-pink-100 bg-white p-3 md:hidden">
                {nav.map(([label, href, Icon]) => (
                  <Link key={href as string} href={href as string} className="flex items-center rounded-xl px-3 py-2 text-sm font-medium hover:bg-pink-50" onClick={() => setOpen(false)}>
                    <Icon className="mr-2 h-4 w-4" /> {label as string}
                  </Link>
                ))}
              </nav>
            )}
          </header>
          <div className="p-4 md:p-8">{children}</div>
        </div>
      </div>
    </PageShell>
  );
}

export function DashboardOverview() {
  const { master, metrics } = useBeautyData();
  const copy = async () => {
    await navigator.clipboard.writeText(publicUrl(master.slug));
    alert('Посилання скопійовано');
  };
  return (
    <DashboardShell title="Кабінет майстра" description="Огляд записів, доходу та швидкі дії.">
      <div className="grid gap-4 md:grid-cols-4">
        <StatsCard title="Сьогодні" value={`${metrics.todayBookings.length}`} description="записів на день" icon={CalendarDays} />
        <StatsCard title="Дохід сьогодні" value={formatMoney(metrics.todayIncome)} description="підтверджені записи" icon={Wallet} />
        <StatsCard title="Цього місяця" value={`${metrics.monthBookings}`} description="активних записів" icon={Activity} />
        <StatsCard title="Клієнти" value={`${metrics.clientsCount}`} description="у CRM базі" icon={Users} />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
        <Card className="border-pink-100">
          <CardHeader>
            <CardTitle>Найближчі записи</CardTitle>
            <CardDescription>Нові заявки та підтверджені записи.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {metrics.upcoming.slice(0, 5).map((booking) => <BookingMiniCard key={booking.id} booking={booking} />)}
            {!metrics.upcoming.length && <EmptyState icon={CalendarDays} title="Записів поки немає" text="Публічна сторінка вже готова для прийому заявок." />}
          </CardContent>
        </Card>
        <Card className="border-pink-100 bg-gradient-to-br from-pink-50 to-violet-50">
          <CardHeader>
            <CardTitle>Публічне посилання</CardTitle>
            <CardDescription>Додайте його в Instagram bio, Telegram або рекламу.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-2xl bg-white p-4 text-sm font-semibold text-slate-700 shadow-sm">{publicUrl(master.slug)}</div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Button onClick={copy} className="bg-pink-600 hover:bg-pink-700"><Copy className="mr-2 h-4 w-4" /> Скопіювати</Button>
              <Button asChild variant="outline" className="bg-white"><Link href={`/master/${master.slug}`}>Відкрити</Link></Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}

function EmptyState({ icon: Icon, title, text }: { icon: any; title: string; text: string }) {
  return (
    <div className="rounded-3xl border border-dashed border-pink-200 bg-pink-50/60 p-8 text-center">
      <Icon className="mx-auto h-10 w-10 text-pink-400" />
      <p className="mt-3 font-bold">{title}</p>
      <p className="mt-1 text-sm text-slate-500">{text}</p>
    </div>
  );
}

function BookingMiniCard({ booking }: { booking: Booking }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-pink-100 bg-white p-4">
      <div>
        <p className="font-semibold">{booking.clientName}</p>
        <p className="text-sm text-slate-500">{booking.date} • {booking.startTime}–{booking.endTime}</p>
      </div>
      <Badge className={statusClass[booking.status]}>{statusLabels[booking.status]}</Badge>
    </div>
  );
}

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const [role, setRole] = useState<'master' | 'admin'>('master');
  const submit = (e: FormEvent) => {
    e.preventDefault();
    window.localStorage.setItem('beautyslot-role', role);
    window.location.href = role === 'admin' ? '/admin' : '/dashboard';
  };
  return (
    <PageShell>
      <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4">
        <Card className="border-pink-100 shadow-xl shadow-pink-100">
          <CardHeader className="text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-pink-600 text-white"><Sparkles /></div>
            <CardTitle className="text-3xl">{mode === 'login' ? 'Вхід' : 'Реєстрація майстра'}</CardTitle>
            <CardDescription>Mock-auth для MVP. Supabase Auth підключається наступним етапом.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={submit}>
              {mode === 'register' && <div><Label>Імʼя</Label><Input placeholder="Ангеліна" /></div>}
              <div><Label>Email</Label><Input type="email" placeholder="master@email.com" /></div>
              <div><Label>Пароль</Label><Input type="password" placeholder="••••••••" /></div>
              <div>
                <Label>Роль для демо</Label>
                <Select value={role} onValueChange={(v) => setRole(v as 'master' | 'admin')}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="master">Майстер</SelectItem>
                    <SelectItem value="admin">Адміністратор</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full bg-pink-600 hover:bg-pink-700">{mode === 'login' ? 'Увійти' : 'Створити акаунт'}</Button>
            </form>
            <Button asChild variant="link" className="mt-3 w-full"><Link href={mode === 'login' ? '/register' : '/login'}>{mode === 'login' ? 'Створити профіль' : 'Вже маю акаунт'}</Link></Button>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}

export function ProfilePage() {
  const { master, updateMaster } = useBeautyData();
  const [form, setForm] = useState(master);
  const save = (e: FormEvent) => {
    e.preventDefault();
    updateMaster({ ...form, specialties: form.specialties });
    alert('Профіль оновлено');
  };
  return (
    <DashboardShell title="Профіль" description="Публічна інформація майстра.">
      <Card className="border-pink-100">
        <CardContent className="pt-6">
          <form onSubmit={save} className="grid gap-4 md:grid-cols-2">
            <div><Label>Імʼя</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>Slug</Label><Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} /></div>
            <div><Label>Телефон</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>Instagram</Label><Input value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} /></div>
            <div><Label>Місто</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
            <div><Label>Адреса</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div><Label>Аватар URL</Label><Input value={form.avatarUrl} onChange={(e) => setForm({ ...form, avatarUrl: e.target.value })} /></div>
            <div><Label>Спеціалізації через кому</Label><Input value={form.specialties.join(', ')} onChange={(e) => setForm({ ...form, specialties: e.target.value.split(',').map((i) => i.trim()) })} /></div>
            <div className="md:col-span-2"><Label>Опис</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            <div className="flex items-center gap-3"><Switch checked={form.isPublic} onCheckedChange={(v) => setForm({ ...form, isPublic: v })} /> <Label>Профіль публічний</Label></div>
            <div className="md:col-span-2"><Button className="bg-pink-600 hover:bg-pink-700">Зберегти</Button></div>
          </form>
        </CardContent>
      </Card>
    </DashboardShell>
  );
}

export function ServicesPage() {
  const { data, master, addService, updateService, deleteService } = useBeautyData();
  const [form, setForm] = useState({ name: '', description: '', categoryId: data.categories[0]?.id || '', price: 600, durationMinutes: 60 });
  const services = data.services.filter((service) => service.masterId === master.id);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    addService({ ...form, masterId: master.id, isActive: true });
    setForm({ ...form, name: '', description: '', price: 600, durationMinutes: 60 });
  };
  return (
    <DashboardShell title="Послуги" description="Категорії, ціни, тривалість і активність послуг.">
      <div className="grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
        <Card className="border-pink-100">
          <CardHeader><CardTitle>Додати послугу</CardTitle><CardDescription>Сервіс одразу зʼявиться на публічній сторінці.</CardDescription></CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={submit}>
              <div><Label>Назва</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Манікюр" /></div>
              <div><Label>Опис</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
              <div><Label>Категорія</Label><Select value={form.categoryId} onValueChange={(v) => setForm({ ...form, categoryId: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{data.categories.map((cat) => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Ціна</Label><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} /></div>
                <div><Label>Тривалість, хв</Label><Input type="number" value={form.durationMinutes} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} /></div>
              </div>
              <Button className="w-full bg-pink-600 hover:bg-pink-700"><Plus className="mr-2 h-4 w-4" /> Додати</Button>
            </form>
          </CardContent>
        </Card>
        <div className="space-y-3">
          {services.map((service) => (
            <Card key={service.id} className="border-pink-100">
              <CardContent className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-bold">{service.name}</p>
                  <p className="text-sm text-slate-500">{service.description}</p>
                  <p className="mt-1 text-sm font-semibold text-pink-600">{formatMoney(service.price)} • {formatDuration(service.durationMinutes)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch checked={service.isActive} onCheckedChange={(v) => updateService(service.id, { isActive: v })} />
                  <Button variant="outline" size="icon" onClick={() => deleteService(service.id)}><Trash2 className="h-4 w-4" /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardShell>
  );
}

export function SchedulePage() {
  const { data } = useBeautyData();
  const days = ['Неділя', 'Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота'];
  return (
    <DashboardShell title="Графік" description="MVP-версія показує робочі години, перерви та логіку доступних слотів.">
      <div className="grid gap-4 md:grid-cols-2">
        {data.workingHours.map((day) => (
          <Card key={day.id} className="border-pink-100">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <p className="font-bold">{days[day.dayOfWeek]}</p>
                <p className="text-sm text-slate-500">{day.isWorking ? `${day.startTime}–${day.endTime}` : 'Вихідний'}</p>
              </div>
              <Badge className={day.isWorking ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'}>{day.isWorking ? 'Працює' : 'Вихідний'}</Badge>
            </CardContent>
          </Card>
        ))}
      </div>
      <Card className="mt-6 border-pink-100">
        <CardHeader><CardTitle>Правила слотів</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          {['Інтервал 30 хв', 'Перерва 14:00–15:00', 'Мінімальне попередження 2 години'].map((item) => <div key={item} className="rounded-2xl bg-pink-50 p-4 font-semibold">{item}</div>)}
        </CardContent>
      </Card>
    </DashboardShell>
  );
}

export function BookingsPage() {
  const { data, updateBookingStatus, deleteBooking } = useBeautyData();
  const [filter, setFilter] = useState<'all' | BookingStatus | 'today' | 'upcoming'>('all');
  const today = getDateString();
  const bookings = data.bookings.filter((booking) => {
    if (filter === 'all') return true;
    if (filter === 'today') return booking.date === today;
    if (filter === 'upcoming') return booking.date >= today && booking.status !== 'cancelled';
    return booking.status === filter;
  });
  return (
    <DashboardShell title="Записи" description="Керування заявками, статусами та історією бронювань.">
      <div className="mb-4 flex flex-wrap gap-2">
        {(['all', 'today', 'upcoming', 'pending', 'confirmed', 'completed', 'cancelled'] as const).map((item) => (
          <Button key={item} variant={filter === item ? 'default' : 'outline'} className={filter === item ? 'bg-pink-600 hover:bg-pink-700' : 'bg-white'} onClick={() => setFilter(item)}>
            {item === 'all' ? 'Усі' : item === 'today' ? 'Сьогодні' : item === 'upcoming' ? 'Майбутні' : statusLabels[item]}
          </Button>
        ))}
      </div>
      <div className="space-y-3">
        {bookings.map((booking) => (
          <Card key={booking.id} className="border-pink-100">
            <CardContent className="p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2"><p className="font-bold">{booking.clientName}</p><Badge className={statusClass[booking.status]}>{statusLabels[booking.status]}</Badge></div>
                  <p className="mt-1 text-sm text-slate-500"><Phone className="mr-1 inline h-4 w-4" />{booking.clientPhone} • {booking.clientInstagram || 'Instagram не вказано'}</p>
                  <p className="mt-1 text-sm text-slate-500"><CalendarDays className="mr-1 inline h-4 w-4" />{booking.date}, {booking.startTime}–{booking.endTime} • {formatMoney(booking.totalPrice)}</p>
                  {booking.comment && <p className="mt-2 rounded-xl bg-pink-50 p-2 text-sm text-slate-600">{booking.comment}</p>}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" onClick={() => updateBookingStatus(booking.id, 'confirmed')}>Підтвердити</Button>
                  <Button variant="outline" onClick={() => updateBookingStatus(booking.id, 'completed')}>Завершити</Button>
                  <Button variant="outline" onClick={() => updateBookingStatus(booking.id, 'cancelled')}>Скасувати</Button>
                  <Button variant="outline" size="icon" onClick={() => deleteBooking(booking.id)}><Trash2 className="h-4 w-4" /></Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {!bookings.length && <EmptyState icon={ListChecks} title="Нічого не знайдено" text="Спробуйте змінити фільтр або створіть тестовий запис з публічної сторінки." />}
      </div>
    </DashboardShell>
  );
}

export function ClientsPage() {
  const { data, updateClientNotes } = useBeautyData();
  const [search, setSearch] = useState('');
  const clients = data.clients.filter((client) => `${client.name} ${client.phone} ${client.instagram}`.toLowerCase().includes(search.toLowerCase()));
  return (
    <DashboardShell title="Клієнти" description="Проста CRM: контакти, візити, витрати й нотатки.">
      <div className="mb-4 max-w-md"><Label>Пошук</Label><div className="relative"><Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" /><Input className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Імʼя, телефон або Instagram" /></div></div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {clients.map((client) => (
          <Card key={client.id} className="border-pink-100">
            <CardHeader>
              <CardTitle>{client.name}</CardTitle>
              <CardDescription>{client.phone} • {client.instagram}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-2xl bg-pink-50 p-3"><p className="text-slate-500">Візити</p><p className="text-lg font-bold">{client.totalVisits}</p></div>
                <div className="rounded-2xl bg-pink-50 p-3"><p className="text-slate-500">Витрачено</p><p className="text-lg font-bold">{formatMoney(client.totalSpent)}</p></div>
              </div>
              <Label className="mt-4 block">Нотатки</Label>
              <Textarea value={client.notes} onChange={(e) => updateClientNotes(client.id, e.target.value)} />
            </CardContent>
          </Card>
        ))}
      </div>
    </DashboardShell>
  );
}

export function PortfolioPage() {
  const { data, master, addPortfolioImage, deletePortfolioImage } = useBeautyData();
  const [url, setUrl] = useState('');
  const [caption, setCaption] = useState('');
  const images = data.portfolioImages.filter((image) => image.masterId === master.id);
  const submit = (e: FormEvent) => {
    e.preventDefault();
    addPortfolioImage(url || 'https://images.unsplash.com/photo-1604654894610-df63bc536371?auto=format&fit=crop&w=700&q=80', caption || 'Нова робота');
    setUrl('');
    setCaption('');
  };
  return (
    <DashboardShell title="Портфоліо" description="Фото робіт для публічної сторінки майстра.">
      <Card className="mb-6 border-pink-100">
        <CardContent className="pt-6">
          <form className="grid gap-3 md:grid-cols-[1fr_1fr_auto]" onSubmit={submit}>
            <div><Label>URL фото</Label><Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." /></div>
            <div><Label>Підпис</Label><Input value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Ніжний нюд" /></div>
            <Button className="self-end bg-pink-600 hover:bg-pink-700"><Plus className="mr-2 h-4 w-4" /> Додати</Button>
          </form>
        </CardContent>
      </Card>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {images.map((image) => (
          <Card key={image.id} className="overflow-hidden border-pink-100">
            <img src={image.imageUrl} alt={image.caption} className="h-60 w-full object-cover" />
            <CardContent className="flex items-center justify-between p-4"><p className="font-semibold">{image.caption}</p><Button variant="outline" size="icon" onClick={() => deletePortfolioImage(image.id)}><Trash2 className="h-4 w-4" /></Button></CardContent>
          </Card>
        ))}
      </div>
    </DashboardShell>
  );
}

export function AnalyticsPage() {
  const { data, metrics } = useBeautyData();
  const monthly = [
    { name: 'Січ', income: 4800, bookings: 8 },
    { name: 'Лют', income: 7200, bookings: 11 },
    { name: 'Бер', income: 8600, bookings: 14 },
    { name: 'Кві', income: 11400, bookings: 18 },
    { name: 'Тра', income: 13600, bookings: 21 },
    { name: 'Чер', income: metrics.monthIncome || 600, bookings: metrics.monthBookings || 1 },
  ];
  const avg = data.bookings.length ? Math.round(data.bookings.reduce((sum, b) => sum + b.totalPrice, 0) / data.bookings.length) : 0;
  return (
    <DashboardShell title="Аналітика" description="Базові показники для MVP.">
      <div className="grid gap-4 md:grid-cols-4">
        <StatsCard title="Дохід місяця" value={formatMoney(metrics.monthIncome)} description="усі активні записи" icon={Wallet} />
        <StatsCard title="Записи" value={`${metrics.monthBookings}`} description="цього місяця" icon={CalendarDays} />
        <StatsCard title="Середній чек" value={formatMoney(avg)} description="по всіх записах" icon={BarChart3} />
        <StatsCard title="Скасовано" value={`${data.bookings.filter((b) => b.status === 'cancelled').length}`} description="заявок" icon={X} />
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Card className="border-pink-100"><CardHeader><CardTitle>Дохід по місяцях</CardTitle></CardHeader><CardContent className="h-72"><ResponsiveContainer width="100%" height="100%"><AreaChart data={monthly}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis /><Tooltip /><Area type="monotone" dataKey="income" /></AreaChart></ResponsiveContainer></CardContent></Card>
        <Card className="border-pink-100"><CardHeader><CardTitle>Кількість записів</CardTitle></CardHeader><CardContent className="h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={monthly}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" /><YAxis /><Tooltip /><Bar dataKey="bookings" /></BarChart></ResponsiveContainer></CardContent></Card>
      </div>
    </DashboardShell>
  );
}

function AdminShell({ children, title, description }: { children: React.ReactNode; title: string; description: string }) {
  const nav: Array<[string, string, any]> = [
    ['Огляд', '/admin', ShieldCheck],
    ['Майстри', '/admin/masters', Users],
    ['Записи', '/admin/bookings', CalendarDays],
    ['Категорії', '/admin/categories', Settings],
  ];
  return (
    <PageShell>
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6 flex flex-col gap-4 rounded-3xl border border-pink-100 bg-white p-5 shadow-sm md:flex-row md:items-center md:justify-between">
          <div><h1 className="text-3xl font-black">{title}</h1><p className="text-slate-500">{description}</p></div>
          <div className="flex flex-wrap gap-2">{nav.map(([label, href, Icon]) => <Button key={href as string} asChild variant="outline" className="bg-white"><Link href={href as string}><Icon className="mr-2 h-4 w-4" /> {label as string}</Link></Button>)}</div>
        </div>
        {children}
      </div>
    </PageShell>
  );
}

export function AdminDashboard() {
  const { data, metrics } = useBeautyData();
  return (
    <AdminShell title="Адмін-панель" description="Платформені метрики та контроль MVP.">
      <div className="grid gap-4 md:grid-cols-4">
        <StatsCard title="Майстри" value={`${data.masters.length}`} description="зареєстровано" icon={Users} />
        <StatsCard title="Активні" value={`${metrics.activeMasters}`} description="публічних профілів" icon={ShieldCheck} />
        <StatsCard title="Записи" value={`${data.bookings.length}`} description="загалом" icon={CalendarDays} />
        <StatsCard title="Клієнти" value={`${data.clients.length}`} description="у системі" icon={Heart} />
      </div>
    </AdminShell>
  );
}

export function AdminMastersPage() {
  const { data, toggleMasterActive } = useBeautyData();
  return (
    <AdminShell title="Майстри" description="Керування профілями майстрів.">
      <div className="space-y-3">
        {data.masters.map((master) => (
          <Card key={master.id} className="border-pink-100"><CardContent className="flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between"><div className="flex items-center gap-4"><img src={master.avatarUrl} alt={master.name} className="h-14 w-14 rounded-2xl object-cover" /><div><p className="font-bold">{master.name}</p><p className="text-sm text-slate-500">/{master.slug} • {master.city}</p></div></div><div className="flex gap-2"><Badge className={master.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}>{master.isActive ? 'Активний' : 'Неактивний'}</Badge><Button variant="outline" onClick={() => toggleMasterActive(master.id)}>{master.isActive ? 'Деактивувати' : 'Активувати'}</Button><Button asChild className="bg-pink-600 hover:bg-pink-700"><Link href={`/master/${master.slug}`}>Відкрити</Link></Button></div></CardContent></Card>
        ))}
      </div>
    </AdminShell>
  );
}

export function AdminBookingsPage() {
  const { data } = useBeautyData();
  return (
    <AdminShell title="Усі записи" description="Платформений список бронювань.">
      <div className="space-y-3">{data.bookings.map((booking) => <BookingMiniCard key={booking.id} booking={booking} />)}</div>
    </AdminShell>
  );
}

export function AdminCategoriesPage() {
  const { data, toggleDefaultCategory } = useBeautyData();
  return (
    <AdminShell title="Категорії" description="Дефолтні категорії для нових майстрів.">
      <div className="grid gap-3 md:grid-cols-3">
        {data.defaultCategories.map((cat) => <Card key={cat.id} className="border-pink-100"><CardContent className="flex items-center justify-between p-4"><p className="font-bold">{cat.name}</p><Switch checked={cat.isActive} onCheckedChange={() => toggleDefaultCategory(cat.id)} /></CardContent></Card>)}
      </div>
    </AdminShell>
  );
}
