import { AuthPage } from '@/components/BeautyApp';

export default function RegisterPage() {
  return <AuthPage mode="register" />;
}
