import { AuthPage } from '@/components/BeautyApp';

export default function LoginPage() {
  return <AuthPage mode="login" />;
}
