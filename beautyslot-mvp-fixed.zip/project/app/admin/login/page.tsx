import { AuthPage } from '@/components/BeautyApp';

export default function AdminLoginPage() {
  return <AuthPage mode="login" />;
}
