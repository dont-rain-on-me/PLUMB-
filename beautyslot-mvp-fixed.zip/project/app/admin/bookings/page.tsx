import { AdminBookingsPage } from '@/components/BeautyApp';

export default function Page() {
  return <AdminBookingsPage />;
}
