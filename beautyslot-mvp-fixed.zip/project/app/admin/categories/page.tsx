import { AdminCategoriesPage } from '@/components/BeautyApp';

export default function Page() {
  return <AdminCategoriesPage />;
}
