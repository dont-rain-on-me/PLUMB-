import { AdminMastersPage } from '@/components/BeautyApp';

export default function Page() {
  return <AdminMastersPage />;
}
