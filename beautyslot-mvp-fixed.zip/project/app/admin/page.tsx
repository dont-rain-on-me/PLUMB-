import { AdminDashboard } from '@/components/BeautyApp';

export default function AdminPage() {
  return <AdminDashboard />;
}
