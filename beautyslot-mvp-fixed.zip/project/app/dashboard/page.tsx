import { DashboardOverview } from '@/components/BeautyApp';

export default function DashboardPage() {
  return <DashboardOverview />;
}
