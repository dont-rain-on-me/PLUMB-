import { BookingsPage } from '@/components/BeautyApp';

export default function Page() {
  return <BookingsPage />;
}
