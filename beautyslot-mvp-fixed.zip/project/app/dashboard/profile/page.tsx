import { ProfilePage } from '@/components/BeautyApp';

export default function Page() {
  return <ProfilePage />;
}
