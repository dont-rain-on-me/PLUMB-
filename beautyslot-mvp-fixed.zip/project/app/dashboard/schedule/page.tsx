import { SchedulePage } from '@/components/BeautyApp';

export default function Page() {
  return <SchedulePage />;
}
