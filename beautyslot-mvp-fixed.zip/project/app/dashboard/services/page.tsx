import { ServicesPage } from '@/components/BeautyApp';

export default function Page() {
  return <ServicesPage />;
}
