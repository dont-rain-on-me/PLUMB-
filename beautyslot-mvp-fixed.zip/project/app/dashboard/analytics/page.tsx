import { AnalyticsPage } from '@/components/BeautyApp';

export default function Page() {
  return <AnalyticsPage />;
}
