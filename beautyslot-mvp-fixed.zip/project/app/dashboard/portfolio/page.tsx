import { PortfolioPage } from '@/components/BeautyApp';

export default function Page() {
  return <PortfolioPage />;
}
