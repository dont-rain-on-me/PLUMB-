import { ClientsPage } from '@/components/BeautyApp';

export default function Page() {
  return <ClientsPage />;
}
