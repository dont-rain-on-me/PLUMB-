import { PublicMasterPage } from '@/components/BeautyApp';

export default function MasterPage({ params }: { params: { slug: string } }) {
  return <PublicMasterPage slug={params.slug} />;
}
