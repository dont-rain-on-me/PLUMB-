import { LandingPage } from '@/components/BeautyApp';

export default function Home() {
  return <LandingPage />;
}
