export type Role = 'client' | 'master' | 'admin';

export type Master = {
  id: string;
  userId: string;
  name: string;
  slug: string;
  avatarUrl: string;
  description: string;
  specialties: string[];
  phone: string;
  instagram: string;
  city: string;
  address: string;
  isPublic: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ServiceCategory = {
  id: string;
  masterId: string;
  name: string;
  sortOrder: number;
  createdAt: string;
};

export type Service = {
  id: string;
  masterId: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
};

export type PortfolioImage = {
  id: string;
  masterId: string;
  imageUrl: string;
  caption: string;
  sortOrder: number;
  createdAt: string;
};

export type WorkingHour = {
  id: string;
  masterId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isWorking: boolean;
};

export type BreakTime = {
  id: string;
  masterId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
};

export type ScheduleException = {
  id: string;
  masterId: string;
  date: string;
  isDayOff: boolean;
  customStartTime?: string;
  customEndTime?: string;
  note?: string;
};

export type Client = {
  id: string;
  masterId: string;
  name: string;
  phone: string;
  instagram: string;
  notes: string;
  totalVisits: number;
  totalSpent: number;
  lastVisitDate?: string;
  createdAt: string;
  updatedAt: string;
};

export type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';

export type Booking = {
  id: string;
  masterId: string;
  clientId: string;
  date: string;
  startTime: string;
  endTime: string;
  totalDurationMinutes: number;
  totalPrice: number;
  status: BookingStatus;
  clientName: string;
  clientPhone: string;
  clientInstagram: string;
  comment: string;
  createdAt: string;
  updatedAt: string;
};

export type BookingService = {
  id: string;
  bookingId: string;
  serviceId: string;
  serviceNameSnapshot: string;
  priceSnapshot: number;
  durationSnapshot: number;
};

export type DefaultCategory = {
  id: string;
  name: string;
  sortOrder: number;
  isActive: boolean;
};

export type BeautyData = {
  masters: Master[];
  categories: ServiceCategory[];
  services: Service[];
  portfolioImages: PortfolioImage[];
  workingHours: WorkingHour[];
  breaks: BreakTime[];
  scheduleExceptions: ScheduleException[];
  clients: Client[];
  bookings: Booking[];
  bookingServices: BookingService[];
  defaultCategories: DefaultCategory[];
};

export type BookingDraft = {
  masterId: string;
  serviceIds: string[];
  date: string;
  startTime: string;
  clientName: string;
  clientPhone: string;
  clientInstagram: string;
  comment: string;
};
