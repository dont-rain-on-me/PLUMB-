import { Booking, BreakTime, ScheduleException, WorkingHour } from './types';

export function timeToMinutes(time: string) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function minutesToTime(minutes: number) {
  const h = Math.floor(minutes / 60)
    .toString()
    .padStart(2, '0');
  const m = (minutes % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
}

export function formatDuration(minutes: number) {
  if (!minutes) return '0 хв';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (!h) return `${m} хв`;
  if (!m) return `${h} год`;
  return `${h} год ${m} хв`;
}

export function formatMoney(amount: number) {
  return new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 0 }).format(amount) + ' ₴';
}

function overlaps(startA: number, endA: number, startB: number, endB: number) {
  return startA < endB && startB < endA;
}

export function getDateString(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

export function getMaxBookingDate(days = 30) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return getDateString(d);
}

export function getAvailableSlots(args: {
  masterId: string;
  date: string;
  durationMinutes: number;
  workingHours: WorkingHour[];
  breaks: BreakTime[];
  exceptions: ScheduleException[];
  bookings: Booking[];
  slotInterval?: number;
  minNoticeMinutes?: number;
}) {
  const {
    masterId,
    date,
    durationMinutes,
    workingHours,
    breaks,
    exceptions,
    bookings,
    slotInterval = 30,
    minNoticeMinutes = 120,
  } = args;

  if (!date || durationMinutes <= 0) return [];

  const selectedDate = new Date(`${date}T12:00:00`);
  const dayOfWeek = selectedDate.getDay();
  const exception = exceptions.find((item) => item.masterId === masterId && item.date === date);
  if (exception?.isDayOff) return [];

  const daySchedule = workingHours.find(
    (item) => item.masterId === masterId && item.dayOfWeek === dayOfWeek
  );
  if (!daySchedule || !daySchedule.isWorking) return [];

  const workStart = timeToMinutes(exception?.customStartTime || daySchedule.startTime);
  const workEnd = timeToMinutes(exception?.customEndTime || daySchedule.endTime);

  const dayBreaks = breaks
    .filter((item) => item.masterId === masterId && item.dayOfWeek === dayOfWeek)
    .map((item) => ({ start: timeToMinutes(item.startTime), end: timeToMinutes(item.endTime) }));

  const dayBookings = bookings
    .filter(
      (item) =>
        item.masterId === masterId &&
        item.date === date &&
        item.status !== 'cancelled'
    )
    .map((item) => ({ start: timeToMinutes(item.startTime), end: timeToMinutes(item.endTime) }));

  const now = new Date();
  const today = getDateString(now);
  const minStartForToday = now.getHours() * 60 + now.getMinutes() + minNoticeMinutes;

  const result: string[] = [];
  for (let start = workStart; start + durationMinutes <= workEnd; start += slotInterval) {
    const end = start + durationMinutes;
    const isPast = date === today && start < minStartForToday;
    const touchesBreak = dayBreaks.some((item) => overlaps(start, end, item.start, item.end));
    const touchesBooking = dayBookings.some((item) => overlaps(start, end, item.start, item.end));
    if (!isPast && !touchesBreak && !touchesBooking) result.push(minutesToTime(start));
  }

  return result;
}
