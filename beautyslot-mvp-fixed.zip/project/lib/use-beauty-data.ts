'use client';

import { useEffect, useMemo, useState } from 'react';
import { seedData } from './seed';
import { BeautyData, Booking, BookingDraft, BookingService, Client, Master, Service } from './types';
import { minutesToTime, timeToMinutes } from './schedule';

const STORAGE_KEY = 'beautyslot-mvp-data-v1';

const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 10)}-${Date.now()}`;

export function useBeautyData() {
  const [data, setData] = useState<BeautyData>(seedData);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setData(JSON.parse(raw));
    } catch (error) {
      console.warn('Cannot load local data', error);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (!isLoaded) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, isLoaded]);

  const master = data.masters[0];

  const updateMaster = (patch: Partial<Master>) => {
    setData((prev) => ({
      ...prev,
      masters: prev.masters.map((item) =>
        item.id === master.id ? { ...item, ...patch, updatedAt: new Date().toISOString() } : item
      ),
    }));
  };

  const addService = (service: Omit<Service, 'id' | 'createdAt' | 'updatedAt' | 'sortOrder'>) => {
    setData((prev) => ({
      ...prev,
      services: [
        ...prev.services,
        {
          ...service,
          id: uid('srv'),
          sortOrder: prev.services.length + 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ],
    }));
  };

  const updateService = (id: string, patch: Partial<Service>) => {
    setData((prev) => ({
      ...prev,
      services: prev.services.map((service) =>
        service.id === id ? { ...service, ...patch, updatedAt: new Date().toISOString() } : service
      ),
    }));
  };

  const deleteService = (id: string) => {
    setData((prev) => ({ ...prev, services: prev.services.filter((service) => service.id !== id) }));
  };

  const updateBookingStatus = (id: string, status: Booking['status']) => {
    setData((prev) => ({
      ...prev,
      bookings: prev.bookings.map((booking) =>
        booking.id === id ? { ...booking, status, updatedAt: new Date().toISOString() } : booking
      ),
    }));
  };

  const deleteBooking = (id: string) => {
    setData((prev) => ({
      ...prev,
      bookings: prev.bookings.filter((booking) => booking.id !== id),
      bookingServices: prev.bookingServices.filter((item) => item.bookingId !== id),
    }));
  };

  const updateClientNotes = (id: string, notes: string) => {
    setData((prev) => ({
      ...prev,
      clients: prev.clients.map((client) =>
        client.id === id ? { ...client, notes, updatedAt: new Date().toISOString() } : client
      ),
    }));
  };

  const addPortfolioImage = (imageUrl: string, caption: string) => {
    setData((prev) => ({
      ...prev,
      portfolioImages: [
        ...prev.portfolioImages,
        {
          id: uid('img'),
          masterId: master.id,
          imageUrl,
          caption,
          sortOrder: prev.portfolioImages.length + 1,
          createdAt: new Date().toISOString(),
        },
      ],
    }));
  };

  const deletePortfolioImage = (id: string) => {
    setData((prev) => ({
      ...prev,
      portfolioImages: prev.portfolioImages.filter((image) => image.id !== id),
    }));
  };

  const toggleMasterActive = (id: string) => {
    setData((prev) => ({
      ...prev,
      masters: prev.masters.map((item) =>
        item.id === id ? { ...item, isActive: !item.isActive, updatedAt: new Date().toISOString() } : item
      ),
    }));
  };

  const toggleDefaultCategory = (id: string) => {
    setData((prev) => ({
      ...prev,
      defaultCategories: prev.defaultCategories.map((item) =>
        item.id === id ? { ...item, isActive: !item.isActive } : item
      ),
    }));
  };

  const createBooking = (draft: BookingDraft) => {
    const selectedServices = data.services.filter((service) => draft.serviceIds.includes(service.id));
    const totalDuration = selectedServices.reduce((sum, service) => sum + service.durationMinutes, 0);
    const totalPrice = selectedServices.reduce((sum, service) => sum + service.price, 0);
    const endTime = minutesToTime(timeToMinutes(draft.startTime) + totalDuration);
    const now = new Date().toISOString();

    let client = data.clients.find(
      (item) => item.masterId === draft.masterId && item.phone.replace(/\D/g, '') === draft.clientPhone.replace(/\D/g, '')
    );

    let newClient: Client | undefined;
    if (!client) {
      newClient = {
        id: uid('client'),
        masterId: draft.masterId,
        name: draft.clientName,
        phone: draft.clientPhone,
        instagram: draft.clientInstagram,
        notes: '',
        totalVisits: 0,
        totalSpent: 0,
        lastVisitDate: undefined,
        createdAt: now,
        updatedAt: now,
      };
      client = newClient;
    }

    const booking: Booking = {
      id: uid('booking'),
      masterId: draft.masterId,
      clientId: client.id,
      date: draft.date,
      startTime: draft.startTime,
      endTime,
      totalDurationMinutes: totalDuration,
      totalPrice,
      status: 'pending',
      clientName: draft.clientName,
      clientPhone: draft.clientPhone,
      clientInstagram: draft.clientInstagram,
      comment: draft.comment,
      createdAt: now,
      updatedAt: now,
    };

    const snapshots: BookingService[] = selectedServices.map((service) => ({
      id: uid('bs'),
      bookingId: booking.id,
      serviceId: service.id,
      serviceNameSnapshot: service.name,
      priceSnapshot: service.price,
      durationSnapshot: service.durationMinutes,
    }));

    setData((prev) => ({
      ...prev,
      clients: newClient
        ? [...prev.clients, newClient]
        : prev.clients.map((item) =>
            item.id === client!.id
              ? {
                  ...item,
                  name: draft.clientName,
                  instagram: draft.clientInstagram,
                  updatedAt: now,
                }
              : item
          ),
      bookings: [...prev.bookings, booking],
      bookingServices: [...prev.bookingServices, ...snapshots],
    }));

    return booking;
  };

  const metrics = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const month = today.slice(0, 7);
    const activeBookings = data.bookings.filter((b) => b.status !== 'cancelled');
    const todayBookings = data.bookings.filter((b) => b.date === today);
    const monthlyBookings = activeBookings.filter((b) => b.date.startsWith(month));
    const todayIncome = todayBookings
      .filter((b) => b.status === 'completed' || b.status === 'confirmed')
      .reduce((sum, b) => sum + b.totalPrice, 0);
    const monthIncome = monthlyBookings.reduce((sum, b) => sum + b.totalPrice, 0);
    return {
      todayBookings,
      upcoming: data.bookings
        .filter((b) => b.date >= today && b.status !== 'cancelled')
        .sort((a, b) => `${a.date}${a.startTime}`.localeCompare(`${b.date}${b.startTime}`)),
      todayIncome,
      monthIncome,
      monthBookings: monthlyBookings.length,
      clientsCount: data.clients.length,
      activeMasters: data.masters.filter((m) => m.isActive).length,
    };
  }, [data]);

  return {
    data,
    setData,
    master,
    metrics,
    updateMaster,
    addService,
    updateService,
    deleteService,
    updateBookingStatus,
    deleteBooking,
    updateClientNotes,
    addPortfolioImage,
    deletePortfolioImage,
    toggleMasterActive,
    toggleDefaultCategory,
    createBooking,
  };
}
