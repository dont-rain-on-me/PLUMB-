# BeautySlot Service Booking MVP

This is a fixed MVP version of the Bolt project. The original preview showed `Start prompting.` because the generated project still had only the default starter page in `app/page.tsx`.

## What is included

- Landing page
- Public master page: `/master/angelina`
- Client booking flow with service selection, date/time slots and confirmation
- Mock localStorage data layer
- Master dashboard
- Profile, services, schedule, bookings, clients, portfolio and analytics pages
- Admin dashboard with masters, bookings and categories

## Run locally

```bash
npm install
npm run dev
```

Then open:

- `/` — landing page
- `/master/angelina` — public booking page
- `/dashboard` — master dashboard
- `/admin` — admin panel

## Notes

Supabase is not required for this MVP preview. The data is stored in browser localStorage. The code is structured so Supabase can be connected later.
